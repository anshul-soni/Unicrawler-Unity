package com.android.features.analytics;

import android.app.Activity;
import android.util.Log;

import com.google.analytics.tracking.android.EasyTracker;
import com.google.analytics.tracking.android.Fields;
import com.google.analytics.tracking.android.GoogleAnalytics;
import com.google.analytics.tracking.android.Logger.LogLevel;
import com.google.analytics.tracking.android.MapBuilder;
import com.google.analytics.tracking.android.Tracker;


public class ANGoogleAnalytics {
	
	private static ANGoogleAnalytics _instance = null;
	
	private  Activity mainActivity = null;
	private  boolean isTrackingStarted = false;
	
	
	public static ANGoogleAnalytics GetInstance() {
		if(_instance == null) {
			_instance =  new ANGoogleAnalytics();
		}
		
		return _instance;
	}
	
	public void startAnalyticsTracking(Activity activity) {
		
		if(isTrackingStarted) {
			return;
		}
		
		mainActivity = activity;
		isTrackingStarted = true;
		EasyTracker.getInstance(mainActivity).activityStart(mainActivity);
	
		

		Log.d("AndroidNative", "Analytics Tracking Sarted");
	}
    
    
    
    public void SetTracker(String trackingID) {
    	 Tracker t =  GetAnalytics().getTracker(trackingID);
    	 GetAnalytics().setDefaultTracker(t);
    }
    
  
    public void SendView(String appScreen) {
    	
    	setKey(Fields.SCREEN_NAME, appScreen);
    	GetTracker().send(MapBuilder.createAppView().build());
    	//clearKey("SCREEN_NAME");
    }
    
    public void SendView() {
    	GetTracker().send(MapBuilder.createAppView().build());
    }
    
    
    public void sendEvent(String category, String action, String label, String value) {
    	Long l;
    	if(value.equals("null")) {
    		l = null;
    	} else {
    		l = Long.parseLong(value);
    	}
    	
    	GetTracker().send(MapBuilder.createEvent(category, action, label, l).build());
    }
    
    public void sendEvent(String category, String action, String label, String value, String key, String v) {
    	Long l;
    	if(value.equals("null")) {
    		l = null;
    	} else {
    		l = Long.parseLong(value);
    	}
    	
    	GetTracker().send(MapBuilder.createEvent(category, action, label, l).set(key, v).build());
    }
    
    
    
    public void setKey(String key, String value) {
    	GetTracker().set(key, value);
    }
    
    public void clearKey(String key) {
    	GetTracker().set(key, null);
    }
    
    public void sendTiming(String category, String intervalInMilliseconds, String name, String label) {
    	Long l = Long.parseLong(intervalInMilliseconds);
    	if(label.equals("null")) {
    		label = null;
    	}
    	if( name.equals("null")) {
    		 name = null;
    	}
    	
    	GetTracker().send(MapBuilder.createTiming(category, l, name, label).build());
    	
    }
    
    public void CreateTransaction(String transactionId, String affiliation, String revenue, String tax, String shipping, String currencyCode) {
    	GetTracker().send( MapBuilder.createTransaction(transactionId, affiliation, Double.parseDouble(revenue) , Double.parseDouble(tax) , Double.parseDouble(tax) , currencyCode).build() );
    }
    
    public void CreateItem(String transactionId, String name, String sku, String category, String price, String quantity, String currencyCode) {
    	GetTracker().send( MapBuilder.createItem(transactionId, name, sku, category, Double.parseDouble(price), Long.parseLong(quantity), currencyCode).build() );
    }
    
    
    public void SetLogLevel(int lvl) {
    	
    	switch(lvl) {
	    	case 0:
	    		GetAnalytics().getLogger().setLogLevel(LogLevel.VERBOSE);
	    		break;
	    	case 1:
	    		GetAnalytics().getLogger().setLogLevel(LogLevel.INFO);
	    		break;
	    	case 2:
	    		GetAnalytics().getLogger().setLogLevel(LogLevel.WARNING);
	    		break;
	    	case 3:
	    		GetAnalytics().getLogger().setLogLevel(LogLevel.ERROR);
	    		break;
    	}
    	
    	
    	
    }
    
    


    public void setDryRun(boolean mode) {
    	GetAnalytics().setDryRun(mode);
    }
    

	
	public void activityStop() {
		if(isTrackingStarted) {
			 EasyTracker.getInstance(mainActivity).activityStop(mainActivity);
		}
	}
	
	
	  private  GoogleAnalytics GetAnalytics() {
		  return GoogleAnalytics.getInstance(mainActivity);
	  } 
	  
	  private  Tracker GetTracker() {
		  return EasyTracker.getInstance(mainActivity);
	  } 
		
	
	
}
