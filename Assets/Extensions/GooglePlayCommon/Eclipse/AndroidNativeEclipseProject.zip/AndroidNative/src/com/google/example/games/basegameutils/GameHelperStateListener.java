package com.google.example.games.basegameutils;

public interface GameHelperStateListener {
	void onStateChange(int state);
}
